function putestimate(estimate, bifdParobj)
%  Replace the estimate parameter

bifdParobj.estimate = estimate;